#ifndef ABSTRACTMENU_H
#define ABSTRACTMENU_H

int getMenuChoice();
#endif
/* create abstractmenu
64070507231 -modify 2023-9-25*/